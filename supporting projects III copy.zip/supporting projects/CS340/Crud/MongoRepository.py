from pymongo import MongoClient
import motor.motor_asyncio


class MongoRepository:
    def __init__(self, connection, database):
        self.mongo_client = motor.motor_asyncio.AsyncIOMotorClient(connection)
        self.db = self.mongo_client[database]

    async def findOne(self, collection, filter):
        document = await self.db[collection].find_one(filter)
        return document

    async def findAll(self, collection, filter, project, sortField, sortValue, pageNumber, pageSize):
        documents = []
        cursor = None
        if(bool(project)):
            cursor = self.db[collection].find(filter, project)
        else:
            cursor = self.db[collection].find(filter)

        if sortField and sortValue:
            cursor.sort(sortField, sortValue)

        if pageNumber and pageSize:
            cursor.skip(pageSize * (pageNumber - 1)).limit(pageSize)

        async for doc in cursor:
            documents.append(doc)
        return documents

    async def count(self, collection, filter):
        n = await self.db[collection].count_documents(filter)
        return n

    async def updateOne(self, collection, filter, updates):
        result = await self.db[collection].update_one(filter, {'$set': updates})
        return result.modified_count

    async def updateMany(self, collection, filter, updates):
        result = await self.db[collection].update_many(filter, {'$set': updates})
        return result.modified_count

    async def updateOneList(self, collection, filter, field, value):
        result = await self.db[collection].update_one(filter, {'$push': {field: value}})
        return result.modified_count

    async def updateManyList(self, collection, filter, field, value):
        result = await self.db[collection].update_many(filter, {'$push': {field: value}})
        return result.modified_count

    async def updateOneIncrement(self, collection, filter, field, value):
        result = await self.db[collection].update_one(filter, {'$inc': {field: value}})
        return result.modified_count

    async def updateManyIncrement(self, collection, filter, field, value):
        result = await self.db[collection].update_many(filter, {'$inc': {field: value}})
        return result.modified_count

    async def deleteOne(self, collection, filter):
        result = await self.db[collection].delete_one(filter)
        return result.deleted_count

    async def deleteMany(self, collection, filter):
        result = await self.db[collection].delete_many(filter)
        return result.deleted_count

    async def insertMany(self, collection, documents):
        result = await self.db[collection].insert_many(documents)
        return result.inserted_ids  





