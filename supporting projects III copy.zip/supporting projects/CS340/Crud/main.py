from ast import literal_eval
from MongoRepository import MongoRepository
from bson.objectid import ObjectId

# for async operations
import asyncio

# Get Current Loop
loop = asyncio.get_event_loop()

# Suppy connection string and database
# Creating Custom class object
client = MongoRepository('mongodb://localhost:27017', 'test')


#--------------------------------------------- findOne -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = filter for where clause. optional but default value should be providerd , default value {}

# returns

# -- dictionary

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# filter = { 'Applicant ID' : 'AB012345-12345678'}

# data =  loop.run_until_complete(client.findOne(collection, filter))
# print(data);


#--------------------------------------------- findAll -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = filter for where clause. optional but default value should be provided , default value {}
# -- project       [dictionary] =  fields to display. optional but default value should be provider , default value {}, 1 for selection, -1 for deselection

# returns

# -- list of dictionary

# ex:
# { _id: 1, Username: 1, FirstName : 1, Education: -1}

# -- sortField  [string] = field to sort with. optional, empty string is default value
# -- sortValue  [number] = 1 for ascending , -1 for descending
# -- pageNumber [number] = for pagination purpose if you want to use it can be 1,2 and so on. default is empty string
# -- pageSize   [number] = for pagination purpose , no of records to select. default is empty string


# usage

# collection = 'employee'
# filter = {}
# project = {}
# sortField = ''
# sortValue = ''
# pageNumber = ''
# pageSize = ''

# data =  loop.run_until_complete(client.findAll(collection, filter, project, sortField, sortValue, pageNumber, pageSize))
# print(data);


#--------------------------------------------- count -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = filter for where clause. optional but default value should be providerd , default value {}

# returns

# -- count of records number in collection

# usage

# collection = 'employee'
# filter = {}


# data =  loop.run_until_complete(client.count(collection, filter))
# print(data);


#--------------------------------------------- updateOne -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- updates       [dictionary] = dictionary for key value pairs to update

# ex : in order to update status and firstname

# { status: 'something', firstname: 'something' }

# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# updates = { 'firstname': 'ABC' }

# data =  loop.run_until_complete(client.updateOne(collection, filter, updates))
# print(data);


#--------------------------------------------- updateMany -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- updates       [dictionary] = dictionary for key value pairs to update

# ex : in order to update status and firstname

# { status: 'something', firstname: 'something' }

# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# updates = { 'firstname': 'CC' }

# data =  loop.run_until_complete(client.updateMany(collection, filter, updates))
# print(data);


#--------------------------------------------- updateOneList -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- field         [string] = field to push in array
# -- value         [string or any] = value to push


# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# field = 'Applicants'
# value = 122
# data =  loop.run_until_complete(client.updateOneList(collection, filter, field, value))
# print(data);


#--------------------------------------------- updateManyList -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- field         [string] = field to push in array
# -- value         [string or any] = value to push


# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# field = 'Applicants'
# value = 122
# data =  loop.run_until_complete(client.updateManyList(collection, filter, field, value))
# print(data);


#--------------------------------------------- updateOneIncrement -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- field         [string] = field to increment by
# -- value         [string or any] = value to increment


# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# field = 'age'
# value = 10
# data =  loop.run_until_complete(client.updateOneIncrement(collection, filter, field, value))
# print(data);


#--------------------------------------------- updateManyIncrement -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = required else it will update all be carefull
# -- field         [string] = field to increment by
# -- value         [string or any] = value to increment


# returns

# -- update records count

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}
# field = 'age'
# value = 10
# data =  loop.run_until_complete(client.updateManyIncrement(collection, filter, field, value))
# print(data);


#--------------------------------------------- deleteOne -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = filter for where clause. required. must bet supplied to delete

# returns

# -- dictionary

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}

# data =  loop.run_until_complete(client.deleteOne(collection, filter))
# print(data);


#--------------------------------------------- deleteMany -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- filter        [dictionary] = filter fresult.deleted_count  or where clause. required. must bet supplied to delete

# returns

# -- dictionary

# usage

# collection = 'employee'
# filter = { '_id' : ObjectId('5dda9b4c722f451f24391fa6')}

# data =  loop.run_until_complete(client.deleteMany(collection, filter))
# print(data);


#--------------------------------------------- insertMany -----------------------------------------------#


# argument

# -- collection    [string] = required)
# -- documents     [list of dictionary]

# returns

# -- list of inserted ids

